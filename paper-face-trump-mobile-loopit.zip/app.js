const canvas = document.querySelector("#stage");
const ctx = canvas.getContext("2d");
const statusText = document.querySelector("#status");
const gestureButton = document.querySelector("#gesture-button");
const video = document.querySelector("#camera");
const cameraPlaceholder = document.querySelector("#camera-placeholder");

const source = document.createElement("canvas");
const sourceCtx = source.getContext("2d");
source.width = 720;
source.height = 900;

const COLS = 18;
const ROWS = 22;
let vertices = [];
let triangles = [];
let width = innerWidth;
let height = innerHeight;
let dpr = Math.min(devicePixelRatio, 2);
let targetProgress = 0.04;
let progress = 0.04;
let rotation = 0;
let targetRotation = 0;
let pointerDown = false;
let lastPointerX = 0;
let gestureActive = false;
let handLandmarker = null;
let lastVideoTime = -1;

function hash(a, b, c = 0) {
  const x = Math.sin(a * 127.1 + b * 311.7 + c * 91.3) * 43758.5453;
  return x - Math.floor(x);
}

function makeDefaultPortrait() {
  const g = sourceCtx.createLinearGradient(0, 0, source.width, source.height);
  g.addColorStop(0, "#d8b194");
  g.addColorStop(0.48, "#9e6c54");
  g.addColorStop(1, "#302620");
  sourceCtx.fillStyle = g;
  sourceCtx.fillRect(0, 0, source.width, source.height);

  const glow = sourceCtx.createRadialGradient(390, 360, 30, 390, 400, 390);
  glow.addColorStop(0, "#f4c9a5");
  glow.addColorStop(0.62, "#bd8064");
  glow.addColorStop(1, "#4c3029");
  sourceCtx.fillStyle = glow;
  sourceCtx.beginPath();
  sourceCtx.ellipse(370, 445, 235, 310, -0.05, 0, Math.PI * 2);
  sourceCtx.fill();

  sourceCtx.fillStyle = "#241d1b";
  sourceCtx.beginPath();
  sourceCtx.ellipse(345, 235, 285, 225, -0.08, Math.PI, Math.PI * 2);
  sourceCtx.lineTo(630, 680);
  sourceCtx.quadraticCurveTo(555, 500, 575, 255);
  sourceCtx.fill();
  sourceCtx.beginPath();
  sourceCtx.moveTo(105, 300);
  sourceCtx.quadraticCurveTo(40, 630, 190, 880);
  sourceCtx.lineTo(300, 870);
  sourceCtx.quadraticCurveTo(170, 520, 235, 250);
  sourceCtx.fill();

  sourceCtx.fillStyle = "#392421";
  sourceCtx.beginPath();
  sourceCtx.ellipse(290, 430, 54, 20, -0.05, 0, Math.PI * 2);
  sourceCtx.ellipse(468, 420, 54, 20, 0.05, 0, Math.PI * 2);
  sourceCtx.fill();
  sourceCtx.fillStyle = "#171311";
  sourceCtx.beginPath();
  sourceCtx.arc(302, 432, 12, 0, Math.PI * 2);
  sourceCtx.arc(457, 422, 12, 0, Math.PI * 2);
  sourceCtx.fill();

  sourceCtx.strokeStyle = "rgba(88,43,39,.55)";
  sourceCtx.lineWidth = 8;
  sourceCtx.lineCap = "round";
  sourceCtx.beginPath();
  sourceCtx.moveTo(330, 610);
  sourceCtx.quadraticCurveTo(388, 640, 450, 600);
  sourceCtx.stroke();

  const vignette = sourceCtx.createRadialGradient(360, 430, 230, 360, 430, 600);
  vignette.addColorStop(0, "rgba(0,0,0,0)");
  vignette.addColorStop(1, "rgba(0,0,0,.75)");
  sourceCtx.fillStyle = vignette;
  sourceCtx.fillRect(0, 0, source.width, source.height);
}

function loadDefaultPortrait() {
  const image = new Image();
  image.onload = () => {
    sourceCtx.clearRect(0, 0, source.width, source.height);
    sourceCtx.drawImage(image, 0, 0, image.width, image.height, 0, 0, source.width, source.height);
  };
  image.src = "./trump-portrait.png";
}

function buildMesh() {
  vertices = [];
  triangles = [];
  for (let y = 0; y <= ROWS; y++) {
    for (let x = 0; x <= COLS; x++) {
      const u = x / COLS;
      const v = y / ROWS;
      const nx = (u - 0.5) * 2;
      const ny = (v - 0.5) * 2;
      const angle = Math.atan2(ny, nx);
      const radial = Math.min(1, Math.hypot(nx, ny));
      const sphereRadius = 0.62 + hash(x, y) * 0.15;
      const ballAngle = angle + (hash(x, y, 2) - 0.5) * 1.8;
      const ballDistance = (0.18 + radial * 0.58) * sphereRadius;
      const ballX = Math.cos(ballAngle) * ballDistance;
      const ballY = Math.sin(ballAngle) * ballDistance;
      const ballZ =
        Math.sqrt(Math.max(0, 1 - radial * radial)) * 0.72 +
        (hash(x, y, 4) - 0.5) * 0.48;
      vertices.push({
        u,
        v,
        flatX: nx * 0.82,
        flatY: ny,
        ballX,
        ballY,
        ballZ,
        jitter: hash(x, y, 8),
      });
    }
  }

  const index = (x, y) => y * (COLS + 1) + x;
  for (let y = 0; y < ROWS; y++) {
    for (let x = 0; x < COLS; x++) {
      const a = index(x, y);
      const b = index(x + 1, y);
      const c = index(x, y + 1);
      const d = index(x + 1, y + 1);
      if ((x + y) % 2) {
        triangles.push([a, b, c], [b, d, c]);
      } else {
        triangles.push([a, b, d], [a, d, c]);
      }
    }
  }
}

function resize() {
  width = innerWidth;
  height = innerHeight;
  dpr = Math.min(devicePixelRatio, 2);
  canvas.width = width * dpr;
  canvas.height = height * dpr;
}

function ease(t) {
  return t * t * (3 - 2 * t);
}

function projectedVertices(time) {
  const t = ease(progress);
  const compact = 1 - t;
  const portraitLayout = height >= width;
  const size = portraitLayout
    ? Math.min(width * 0.56, height * 0.42)
    : Math.min(width * 0.34, height * 0.46);
  const centerX = width * 0.5;
  const centerY = portraitLayout ? height * 0.45 : height * 0.48;
  const cos = Math.cos(rotation * compact);
  const sin = Math.sin(rotation * compact);

  return vertices.map((vertex) => {
    const flutter = Math.sin(time * 0.0014 + vertex.jitter * 12) * 0.025 * compact;
    let x = vertex.ballX * compact + vertex.flatX * t;
    let y = vertex.ballY * compact + vertex.flatY * t;
    let z = (vertex.ballZ + flutter) * compact;
    const rx = x * cos - z * sin;
    z = x * sin + z * cos;
    x = rx;
    const perspective = 1 / (1.25 - z * 0.24);
    return {
      x: centerX + x * size * perspective,
      y: centerY + y * size * perspective,
      z,
      u: vertex.u * source.width,
      v: vertex.v * source.height,
    };
  });
}

function drawTriangle(image, p0, p1, p2, shade) {
  const den =
    p0.u * (p1.v - p2.v) +
    p1.u * (p2.v - p0.v) +
    p2.u * (p0.v - p1.v);
  if (Math.abs(den) < 0.001) return;
  const a =
    (p0.x * (p1.v - p2.v) + p1.x * (p2.v - p0.v) + p2.x * (p0.v - p1.v)) /
    den;
  const b =
    (p0.y * (p1.v - p2.v) + p1.y * (p2.v - p0.v) + p2.y * (p0.v - p1.v)) /
    den;
  const c =
    (p0.x * (p2.u - p1.u) + p1.x * (p0.u - p2.u) + p2.x * (p1.u - p0.u)) /
    den;
  const d =
    (p0.y * (p2.u - p1.u) + p1.y * (p0.u - p2.u) + p2.y * (p1.u - p0.u)) /
    den;
  const e =
    (p0.x * (p1.u * p2.v - p2.u * p1.v) +
      p1.x * (p2.u * p0.v - p0.u * p2.v) +
      p2.x * (p0.u * p1.v - p1.u * p0.v)) /
    den;
  const f =
    (p0.y * (p1.u * p2.v - p2.u * p1.v) +
      p1.y * (p2.u * p0.v - p0.u * p2.v) +
      p2.y * (p0.u * p1.v - p1.u * p0.v)) /
    den;

  ctx.save();
  ctx.beginPath();
  ctx.moveTo(p0.x, p0.y);
  ctx.lineTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.closePath();
  ctx.clip();
  ctx.setTransform(a * dpr, b * dpr, c * dpr, d * dpr, e * dpr, f * dpr);
  ctx.drawImage(image, 0, 0);
  ctx.restore();

  if (shade > 0.02) {
    ctx.fillStyle = `rgba(0,0,0,${shade})`;
    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y);
    ctx.lineTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.closePath();
    ctx.fill();
  }
}

function render(time) {
  progress += (targetProgress - progress) * 0.09;
  rotation += (targetRotation - rotation) * 0.08;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);

  const bg = ctx.createRadialGradient(width * 0.5, height * 0.44, 0, width * 0.5, height * 0.44, height * 0.7);
  bg.addColorStop(0, "#181512");
  bg.addColorStop(0.5, "#0b0a09");
  bg.addColorStop(1, "#050505");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  const points = projectedVertices(time);
  const sorted = triangles
    .map((ids) => ({
      ids,
      z: (points[ids[0]].z + points[ids[1]].z + points[ids[2]].z) / 3,
    }))
    .sort((a, b) => a.z - b.z);

  ctx.shadowColor = "rgba(0,0,0,.6)";
  ctx.shadowBlur = 12 * (1 - progress);
  for (const triangle of sorted) {
    const [p0, p1, p2] = triangle.ids.map((id) => points[id]);
    const cross = (p1.x - p0.x) * (p2.y - p0.y) - (p1.y - p0.y) * (p2.x - p0.x);
    const shade = Math.min(0.62, Math.max(0, (1 - progress) * (0.15 + Math.abs(cross % 37) / 65 - triangle.z * 0.1)));
    drawTriangle(source, p0, p1, p2, shade);
  }
  ctx.shadowBlur = 0;

  if (gestureActive) detectHand();
  requestAnimationFrame(render);
}

async function startGesture() {
  gestureButton.disabled = true;
  gestureButton.textContent = "LOADING GESTURE MODEL...";
  statusText.textContent = "CONNECTING TO CAMERA";
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user", width: 640, height: 480 },
      audio: false,
    });
    video.srcObject = stream;
    await video.play();
    cameraPlaceholder.style.display = "none";

    const vision = await import("https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22-rc.20250304/+esm");
    const fileset = await vision.FilesetResolver.forVisionTasks(
      "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.22-rc.20250304/wasm",
    );
    handLandmarker = await vision.HandLandmarker.createFromOptions(fileset, {
      baseOptions: {
        modelAssetPath:
          "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task",
        delegate: "GPU",
      },
      runningMode: "VIDEO",
      numHands: 1,
      minHandDetectionConfidence: 0.55,
      minTrackingConfidence: 0.55,
    });
    gestureActive = true;
    gestureButton.textContent = "GESTURE ACTIVE";
    statusText.textContent = "OPEN OR CLOSE YOUR HAND";
  } catch (error) {
    console.error(error);
    gestureButton.disabled = false;
    gestureButton.textContent = "RETRY GESTURE";
    statusText.textContent = "CAMERA UNAVAILABLE - DRAG TO INTERACT";
  }
}

function detectHand() {
  if (!handLandmarker || video.readyState < 2 || video.currentTime === lastVideoTime) return;
  lastVideoTime = video.currentTime;
  const result = handLandmarker.detectForVideo(video, performance.now());
  const hand = result.landmarks?.[0];
  if (!hand) {
    statusText.textContent = "PLACE ONE HAND INSIDE THE CAMERA";
    return;
  }

  const palm = distance(hand[0], hand[9]);
  const tips = [4, 8, 12, 16, 20];
  const joints = [2, 5, 9, 13, 17];
  const openness =
    tips.reduce((sum, tip, i) => sum + distance(hand[tip], hand[joints[i]]) / palm, 0) /
    tips.length;
  targetProgress = Math.max(0.03, Math.min(1, (openness - 0.95) / 1.25));
  statusText.textContent = targetProgress > 0.65 ? "PALM OPEN" : "FIST CLOSED";
}

function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

gestureButton.addEventListener("click", startGesture);

canvas.addEventListener("pointerdown", (event) => {
  pointerDown = true;
  lastPointerX = event.clientX;
  canvas.setPointerCapture(event.pointerId);
});

canvas.addEventListener("pointermove", (event) => {
  if (!pointerDown) return;
  gestureActive = false;
  const delta = event.clientX - lastPointerX;
  targetProgress = Math.max(0, Math.min(1, targetProgress + delta / Math.min(width, 700)));
  targetRotation += delta * 0.0015;
  lastPointerX = event.clientX;
  statusText.textContent = "DRAG CONTROL ACTIVE";
});

canvas.addEventListener("pointerup", () => {
  pointerDown = false;
});

canvas.addEventListener("wheel", (event) => {
  gestureActive = false;
  targetProgress = Math.max(0, Math.min(1, targetProgress - event.deltaY * 0.001));
});

addEventListener("resize", resize);
makeDefaultPortrait();
loadDefaultPortrait();
buildMesh();
resize();
requestAnimationFrame(render);
