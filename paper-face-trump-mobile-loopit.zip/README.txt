Loopit package entry: index.html

The interaction works with mouse, touch, wheel, and the bottom slider.
Gesture control requires:
1. Camera permission enabled for the Loopit playable iframe/page.
2. Network access to the MediaPipe CDN and model URLs.

If either requirement is unavailable, the other controls continue to work.
