Loopit-ready static package for the uploaded Construct 2 HTML5 game.

Entry: index.html
Game files: /game/index.html, /game/c2runtime.js, /game/data.js, /game/images, /game/media
Recommended hosting mode: static site / iframe wrapper.
The original Construct 2 index was patched to remove missing appcache, manifest, icon, and service worker references.
